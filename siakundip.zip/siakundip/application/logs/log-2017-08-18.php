<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2017-08-18 17:33:29 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`Pencil_pharmacy`.`mp_productslist`, CONSTRAINT `category_medicine_fk` FOREIGN KEY (`category_id`) REFERENCES `mp_category` (`id`)) - Invalid query: DELETE FROM `mp_category`
WHERE `id` = '4'
ERROR - 2017-08-18 17:33:30 --> Query error: Cannot delete or update a parent row: a foreign key constraint fails (`Pencil_pharmacy`.`mp_productslist`, CONSTRAINT `category_medicine_fk` FOREIGN KEY (`category_id`) REFERENCES `mp_category` (`id`)) - Invalid query: DELETE FROM `mp_category`
WHERE `id` = '4'
